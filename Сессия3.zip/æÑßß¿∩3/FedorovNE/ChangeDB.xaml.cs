﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FedorovNE
{
    /// <summary>
    /// Логика взаимодействия для ChangeDB.xaml
    /// </summary>
    public partial class ChangeDB : Page
    {
        private Abonent _abo = new Abonent();
        public ChangeDB()
        {
            DataContext = _abo;

            InitializeComponent();
        }

        private void BtnBack3_Click(object sender, RoutedEventArgs e)
        {
            Manager.MEF.Navigate(new Abonent());
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_abo.Name))
                errors.AppendLine("Заполните все поля ввода");
            if(errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }
        }
    }
}
